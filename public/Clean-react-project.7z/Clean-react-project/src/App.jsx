function App() {
  return (
    <>
      <h1>Website</h1>
    </>
  );
}

export default App;
