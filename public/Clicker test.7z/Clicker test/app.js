const main = document.getElementsByTagName('main')[0];
const counterField = document.getElementById('counter');
const counterText = document.getElementById('counterText');
const pElement = document.getElementById('p');
let counter = 0;
let end = true;
let time = document.getElementById('time');
const timeField = document.getElementById('timeField');
counterField.textContent = counter;

let counterTime = 5;
time.textContent = `${counterTime}s`;
let interval;

function startTimeClicker() {
    time.textContent = `5s`;
    counterTime = 5;

    interval = setInterval(() => {
        counterTime -= 1;
        time.textContent = `${counterTime}s`;
    }, 1000);
}

function endTimeClicker() {
    counterTime = 0;
    clearInterval(interval);
}

main.addEventListener('click', () => {
    counter++;
    setTimeout(() => {
        main.style.border = '12px solid var(--color3)';
    }, 0);

    setTimeout(() => {
        main.style.border = '12px solid var(--color2)';
    }, 100);
    if (counter === 1) {
        startTime();
        startTimeClicker();

        promis()
            .then(() => {
                end = true;
                endTime(end);
            })
            .then(() => {
                exit();
            });
    }
    counterField.textContent = counter;
    setTimeout(() => {
    }, 0);
});

const promis = () => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve();
        }, 5000);
    });
}

function startTime() {
    pElement.style.display = 'none';
}

function endTime(end) {
    if (end === true) {
        alert(`Result: ${counter / 5} clicks/s. Bravo!`);
        end = false;
    }
    endTimeClicker();
}

function exit() {
    counter = 0;
    counterField.textContent = counter;
    pElement.style.display = 'block';
    end = false;

    setTimeout(() => {
        counterField.textContent = 0;
    }, 0);
}