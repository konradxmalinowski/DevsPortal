const form = document.getElementsByTagName('form')[0];
form.addEventListener('submit', (event) => {
    event.preventDefault();
});

function baner(emoji) {
    Notification.requestPermission().then((permission) => {
        if (permission === 'granted') {
            new Notification('Rating', {
                body: `You have just send your opinion (${emoji})`,
                tag: 'Rating',
                lang: 'en',
                dir: 'ltr',
            })
        }
    })
}

function firstE(emoji) {
    baner(emoji);
}

function secondE(emoji) {
    baner(emoji);
}

function thirdE(emoji) {
    baner(emoji);
}

function fourthE(emoji) {
    baner(emoji);
}

function fivethE(emoji) {
    baner(emoji);
}